
# Blogging-Website
You are welcomed here. Make and kind of changes you want to do. Just fork the repo and push your fantastic upgradations.

![image](https://user-images.githubusercontent.com/61585443/172445375-1885ff45-5bf7-4ef6-b3fb-1c38c8c51b63.png)

Here You can find many features which every website has. All the meta tag features and many more you can explore it. **Just fork this repo!!!**

![image](https://user-images.githubusercontent.com/61585443/172445643-a6c31703-bc73-4fbf-8081-2d4464b50ced.png)

Some **CRUD** functionalities like Edit, Create as shown in 1st image

![image](https://user-images.githubusercontent.com/61585443/172446528-8196c5f2-37ed-448b-8ed8-cd8bc62461f5.png)

You can find recent posts as well
![image](https://user-images.githubusercontent.com/61585443/172446584-928aa5c1-4034-42fc-8ce6-219aabc832e5.png)

![image](https://user-images.githubusercontent.com/61585443/172446467-9fc37022-8f23-4ad8-9df6-d9d29e75b16c.png)

The Commenting system is powered by  <a href="https://utteranc.es/">utteranc.es</a>

![image](https://user-images.githubusercontent.com/61585443/172446800-9559b132-87a4-47f7-8e68-29cfd9710059.png)

## Completed 
